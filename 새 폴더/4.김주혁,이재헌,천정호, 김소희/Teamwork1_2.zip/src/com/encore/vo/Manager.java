package com.encore.vo;

public class Manager {
	private int ssn;
	private String name;

	public Manager(int ssn, String name) {
		this.ssn = ssn;
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
