package com.encore.service;

import java.util.ArrayList;

import com.encore.vo.Course;

public interface EnrollService {
	// �л��� Course�� Course�� �߰����ش�.
	void addCourse(ArrayList<Course> courses);
	
	void addCourse(Course course);
	
	void enrollCourse(String courseName);
	
	ArrayList<Course> searchCourse();

	ArrayList<Course> searchCourse(String courseName);

	ArrayList<Course> searchCourse(int courseNumber);

	ArrayList<Course> searchEnrolledCourse();

	ArrayList<Course> searchEnrolledCourse(String courseName);

	ArrayList<Course> searchEnrolledCourse(int courseNumber);
	
	void deleteCourse();

	void deleteCourse(String courseName);

	void deleteCourse(int courseNumber);

}