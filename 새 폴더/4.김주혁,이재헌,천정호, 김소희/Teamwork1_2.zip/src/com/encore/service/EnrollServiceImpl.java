package com.encore.service;

import java.util.ArrayList;

import com.encore.vo.Course;
import com.encore.vo.Student;

public class EnrollServiceImpl implements EnrollService {
	Student student;
	ArrayList<Course> courses;

	public EnrollServiceImpl(ArrayList<Course> courses, Student student) {
		this.student = student;
		this.courses = courses;
	}


	@Override
	public void addCourse(ArrayList<Course> courses) {
		courses.addAll(courses);
		System.out.println(courses + " �ڽ����� ��Ͽ� �߰��߽��ϴ�.");
	}

	@Override
	public void addCourse(Course course) {
		courses.add(course);
		System.out.println(course.getName() + " �ڽ��� �߰��߽��ϴ�.");
	}
	
	@Override
	public void enrollCourse(String coursename) {
		for (Course course : courses) {
			if (course.getName() == coursename) {
				student.addCourse(course);
				System.out.println(student.getName() + "���� " + course.getName() + " ���� ��(��) ������û �߽��ϴ�.");
				break;
			}
		}

	}

	@Override
	public ArrayList<Course> searchCourse() {
		return courses;
	}

	@Override
	public ArrayList<Course> searchCourse(String courseName) {
		ArrayList<Course> ret = new ArrayList<Course>();
		for (Course course : courses) {
			if (course.getName().equals(courseName)) {
				ret.add(course);
			}
		}
		return ret;
	}

	@Override
	public ArrayList<Course> searchCourse(int courseNumber) {
		ArrayList<Course> ret = new ArrayList<Course>();
		for (Course course : courses) {
			if (course.getNum() == courseNumber) {
				ret.add(course);
			}
		}
		return ret;
	}

	@Override
	public void deleteCourse() {
		student.getCourses().clear();
		System.out.println(student.getName() +"�� courses �ʱ�ȭ.");
	}

	@Override
	public void deleteCourse(String courseName) {
		for (Course course : student.getCourses()) {
			if (course.getName().equals(courseName)) {
				student.getCourses().remove(course);
				return;
			}
		}
		System.out.println("�̸��� ���� �ڽ��� �����ϴ�.");
	}

	@Override
	public void deleteCourse(int courseNumber) {
		for (Course course : student.getCourses()) {
			if (course.getNum() == courseNumber) {
				courses.remove(course);
				return;
			}
		}
		System.out.println("�ڽ��ѹ��� ���� �ڽ��� �����ϴ�.");

	}

	@Override
	public ArrayList<Course> searchEnrolledCourse() {
		ArrayList<Course> mycourse = student.getCourses();
		return mycourse;
	}

	@Override
	public ArrayList<Course> searchEnrolledCourse(String courseName) {
		ArrayList<Course> mycourse = new ArrayList<Course>();

		for (Course course : student.getCourses()) {
			if (course.getName().equals(courseName)) {
				mycourse.add(course);
			}
		}
		return mycourse;
	}

	@Override
	public ArrayList<Course> searchEnrolledCourse(int courseNumber) {
		ArrayList<Course> mycourse = new ArrayList<Course>();

		for (Course course : student.getCourses()) {
			if (course.getNum() == courseNumber) {
				mycourse.add(course);
			}
		}
		return mycourse;
	}


}
